(()=>{chrome.action.setBadgeText({text:"ok"});})();
