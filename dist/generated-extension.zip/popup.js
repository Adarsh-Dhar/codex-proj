(()=>{document.getElementById("go").addEventListener("click",()=>{});})();
